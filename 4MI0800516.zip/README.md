# Spoopify
Spoopify is a desktop application that allows playing, managing and organizing music files. The user can listen to music, create playlists, monitor their own music preferences through statistics and import/export playlists to an external file.

TO RUN
1) pip install requirements.txt
2) python main.py